<!DOCTYPE html>
<html lang="en"> 
<head>
<?php require_once "head.php"; ?>
</head> 
<body>
<?php require_once "menu.php"; ?>
</br>
<div class="container"> 
    <?php require_once "separadorComidas.php";?> 
    <?php require_once "cardsComidas.php"; ?> 
    <?php require_once "separadorFooter.php";?>   
</div>  
</br> </br> </br></br>
<?php require_once "script.php"; ?>
</body>
</html>