<nav class="navbar navbar-expand-lg navbar-light bg-warning ">
  <a class="navbar-brand" href="#"><img src="img/prontoW.png" width="" height="45px" alt=""/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <li class="nav-item">
        <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
        <a class="nav-item nav-link" href="ofertas.php">ver Ofertas</a>
        </li>
        <li class="nav-item">
        <a class="nav-item nav-link" href="comidas.php">Comidas</a>
        </li>
        <li class="nav-item">
        <a class="nav-item nav-link" href="#">Comprar</a>
        </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    </form>
    
  </div>
</nav>







