<div class="row">

    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/patamuslo.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">PATAMUSLO </h5>
            <p class="card-text">x 3 Kilos</p>
            <a href="#" class="btn btn-info m-3">$ 279</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>

    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/trozado.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">TROZADO de POLLO</h5>
            <p class="card-text">x kilo $ 140 OFERTA X 2 Kilos</p>
            <a href="#" class="btn btn-info m-3">$ 260</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>
 
    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/pancasero.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">PAN CASERO</h5>
            <p class="card-text">X UNIDAD</p>
            <a href="#" class="btn btn-info m-3">$ 50</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>
 

    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/quibrah.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">BRAHMITAS - QUILMITAS</h5>
            <p class="card-text">Envase $15</p>
            <a href="#" class="btn btn-info m-3">$ 25</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>

    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/brahma.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">Brahma</h5>
            <p class="card-text">$ 90 cada una OFERTA x dos</p>
            <a href="#" class="btn btn-info m-3">$ 170</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>
 
    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/quilmes.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">Quilmes</h5>
            <p class="card-text">$ 85 cada una OFERTA x dos</p>
            <a href="#" class="btn btn-info m-3">$ 160</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>

    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/pizzas-listas.jpg" height="180px" class="card-img-top shadow-sm" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">Pizza Lista</h5>
            <p class="card-text">Muzarella</p>
            <a href="#" class="btn btn-info m-3">$ 150</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>
 

</div>