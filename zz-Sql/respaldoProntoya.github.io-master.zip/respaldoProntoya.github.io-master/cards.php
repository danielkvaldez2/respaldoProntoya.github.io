<div class="row ">

    <div class="col-sm" style="max-width:310px; margin: 0 auto; margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/pollo-asado.jpg"   height="180px" class="card-img-top" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">Pollo c/mandioca</h5>
            <p class="card-text">por unidad</p>
            <a href="#" class="btn btn-info m-3">$ 290</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>

    <div class="col-sm " style="max-width:310px; margin: 0 auto;margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/asado.jpg"  height="180px" class="card-img-top" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">Costilla Asado c/mandioca</h5>
            <p class="card-text">Venta por kilogramo</p>
            <a href="#" class="btn btn-info m-3">$ 590</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>
 
    <div class="col-sm " style="max-width:310px; margin: 0 auto;margin-bottom:20px;">
        <div class="card"  >
        <img src="img/productos/empanadas.jpg"  height="180px" class="card-img-top" alt="hry">
        <div class="card-body text-center">
            <h5 class="card-title">Empanadas</h5>
            <p class="card-text">por docena</p>
            <a href="#" class="btn btn-info m-3">$ 300</a>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        </div>
    </div>
 
    

</div>