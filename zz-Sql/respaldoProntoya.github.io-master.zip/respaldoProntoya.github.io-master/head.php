<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
        <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
        <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />
          <title>Pronto ya</title>
         <meta name="description" content="Combustibles - Supermercado - Almacen - Bebidas - Comestibles - Perfumeria">   
         <meta name="language" content="es" /> 
                          <meta name="dc.creator" content="danielkvaldez" /> 
                          <meta name="revisit" content="1 day" /> 
                          <meta name="description" content= "Posadas Misiones Argentina " />
                          <meta name="keywords" content="Combustibles Supermercado Almacen Bazar Panificados " />
                          <meta name="robots" content="index, follow" />
                          <meta name="apple-mobile-web-app-capable" content="yes" />
                          <meta name="apple-mobile-web-app-status-bar-style" content="black" /><!-- or black-traslucent -->
                          <link rel="apple-touch-startup-image" href="http://www.prontoya.com/pronto152.png" />  
          <link rel="shortcut icon" href="http://www.prontoya.com/favicon.ico" type="image/x-icon">
          <link rel="shortcut icon" type="image/png" href="http://www.prontoya.com/pronto16.png" />  
          <link rel="shortcut icon" type="image/svg+xml" href="http://www.prontoya.com/prontoSVG.svg" /> 
          <link rel="apple-touch-icon" size="" href="http://www.prontoya.com/pronto152.png" />  
      
          <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" >

          <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        

          <script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5e6278bc1de37a001285e36f&product=inline-share-buttons' async='async'></script>
        
          <link rel="stylesheet" type="text/css" href="css/StyleMain.css" >
