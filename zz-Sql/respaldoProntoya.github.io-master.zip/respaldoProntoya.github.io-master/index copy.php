<!DOCTYPE html>
<html lang="en"> 
<head>
<?php require_once "head.php"; ?> 
</head> 
<body>
<?php require_once "menu.php"; ?>
        
        </br> </br> 
    <div style="text-align: center;">
        <img src="img/fondo00.jpg" width="" height="100%" alt="" />
    </div>

<div class="container">


    <div class="ofertasCajon">
                </br> </br> </br> </br> </br>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Delivery  </span>  </br>
                    <span class="descripOCT">de 8 am. A 00:45 pm.</span>  </br>
                    <span class="tituloOCT"> de Lunes a Domingo </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pronto152.png" height="150px" alt="" class="fotoCajitaOferta">
                </div>  
                         
        </div>

         
         <div class="ofertaCajita">
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/asado.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Domingos </span>  </br>
                    <span class="descripOCT">ASADO-POLLO-MATAMBRE </span>  </br>
                    <span class="tituloOCT">PARRILLA  </span> 
                </div>
        </div>


        <div class="ofertaCajita">
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pollo-asado.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Pollo  </span>  </br>
                    <span class="descripOCT">con Mandioca </span>  </br>
                    <span class="tituloOCT"> $ 300.  </span> 
                </div>
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/asado.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Costilla Vacio  </span>  </br>
                    <span class="descripOCT">con Mandioca </span>  </br>
                    <span class="tituloOCT"> $ 599 kg  </span> 
                </div>
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> PEDIDOS </span>  </br>
                    <span class="descripOCT">Reserva Temprano al whatsapp </span>  </br>
                    <span class="tituloOCT">3764-634166 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pronto152.png" height="150px" alt="" class="fotoCajitaOferta">
                </div>              
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Débito </span>  </br>
                    <span class="descripOCT">Pedidos a domicilio. </span>  </br>
                    <span class="tituloOCT"> Crédito </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/tarjetas.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>       
        </div>
        
        <div class="ofertaCajita">
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/patamuslo.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">PATAMUSLO </span>  </br>
                    <span class="descripOCT">X 3 KILOS </span>  </br>
                    <span class="tituloOCT">$ 279 </span> 
                </div>
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Brahma $ 90</span>  </br>
                    <span class="descripOCT">PROMO 2 X </span>  </br>
                    <span class="tituloOCT">$ 170 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/quibrabud.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>      
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">Quilmes $85 </span>  </br>
                    <span class="descripOCT">PROMO 2 X </span>  </br>
                    <span class="tituloOCT">$ 160 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/quibrabud.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>      
        </div>
        
      
        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> BRAHMITA </span>  </br>
                    <span class="descripOCT"> (ENVASE $15) </span>  </br>
                    <span class="tituloOCT">$ 25 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/quibra.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>      
        </div>
        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">HARINA 000 </span>  </br>
                    <span class="descripOCT">1 Kilo </span>  </br>
                    <span class="tituloOCT">$ 45 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/harinaEstrellaDelParana.png" height="150px" alt="" class="fotoCajitaOferta">
                </div>     
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/lecheIlolay.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">LECHE ILOLAY </span>  </br>
                    <span class="descripOCT">1L.Larga Vida</span>  </br>
                    <span class="tituloOCT">$ 90 </span> 
                </div>
        </div>
        
        <div class="ofertaCajita">      
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">PAN</span>  </br>
                    <span class="descripOCT">X 500GR</span>  </br>
                    <span class="tituloOCT">$ 40 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/mignon.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
        </div>

        <div class="ofertaCajita">      
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">PAN CASERO</span>  </br>
                    <span class="descripOCT">X UNIDAD</span>  </br>
                    <span class="tituloOCT">$ 40 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pancasero01.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
        </div>
        
      

        <div class="ofertaCajita">      
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT">TROZADO de POLLO</span>  </br>
                    <span class="descripOCT">x kilo $ 140</span>  </br>
                    <span class="tituloOCT">2 x $ 260  </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pollo01.jpg" height="150px" alt="" class="fotoCajitaOferta">
                </div>
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> PEDIDOS </span>  </br>
                    <span class="descripOCT">Reservas </span>  </br>
                    <span class="tituloOCT">3764-634166 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pronto152.png"   alt="" class="fotoCajitaOferta">
                </div>       
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> Débito </span>  </br>
                    <span class="descripOCT">Pedidos a domicilio. </span>  </br>
                    <span class="tituloOCT"> Crédito </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pronto152.png"    alt="" class="fotoCajitaOferta">
                </div>       
        </div>

        <div class="ofertaCajita">
                <div class="ofertaCajitaTexto">
                    <span class="tituloOCT"> PEDIDOS </span>  </br>
                    <span class="descripOCT">Reservas </span>  </br>
                    <span class="tituloOCT">3764-634166 </span> 
                </div>
                <div class="ofertaCajitaFoto">
                    <img src="img/productos/pronto152.png"    alt="" class="fotoCajitaOferta">
                </div>       
        </div>

        <div class="ofertaCajita">      
            <div class="ofertaCajitaMedia">
                    <a href="https://wa.me/543764634166?text=Me%20gustaría%20que%20me%20envien%20" target="_blank"  ><img src="img/logo_whatsapp.png" width="90px" height="90px" alt="" title="comunicate con Sandra" ></a>
            </div>
            <div class="ofertaCajitaMedia">
                   <a href="https://wa.me/542262630155?text=Me%20gustaría%20que%20me%20envien%20" target="_blank" ><img src="img/logo_whatsapp.png"  width="90px" height="90px" alt="" title="comunicate con Daniel" ></a>
            </div>
        </div>
        <div class="ofertaCajita">
            <div class="ofertaCajitaMedia2">      
                    <img src="http://www.codigos-qr.com/qr/php/qr_img.php?d=http%3A%2F%2Fprontoya.com&s=10&e=m"  width="110px" height="110px"  alt="Generador de Códigos QR Codes"/>
            </div>
            <div class="sharethis-inline-share-buttons"></div>  
        </div>
        <div class="ofertaCajita">
            
          
        </div>
   </div>
        </br> </br></br></br></br>
        </br> </br></br></br></br>
      
        </br></br></br>
        dov
</div><!-- div container -->

</body>
</html>



