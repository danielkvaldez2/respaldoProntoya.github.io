<!DOCTYPE html>
<html lang="en"> 
<head>
<?php require_once "../head.php"; ?>
</head> 
<body>
<!-- *******************************************************************************--> 
<!-- *******************************************************************************-->  
<?php 

echo "<center><hr></center>";
echo "<center><h1><font color='red'>__ERROR interno del SERVIDOR__</font></h1></center>";
echo "<center>---->".[error_reporting()]."</center>";
echo "<center><h1><font color='#596E6E'>Prontoya.com</font></h1></center>";
echo "<center><hr></center>";
echo "<center><h2><font color='#596E6E'>Tel.54-3764-634155 </font></h2></center>";
echo "<center><hr></center>";
echo "<center><h4><font color='#596E6E'>Site Responsive Desing - Powered by kvalhost  </font></h4></center>";
echo "<center><hr></center>";
?>
<!-- *******************************************************************************--> 
<!-- *******************************************************************************-->  

<?php require_once "../separadorFooter.php";?>  
</body>
</html>