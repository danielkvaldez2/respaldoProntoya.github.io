<div class="jumbotron jumbotron-fluid bg-warning text-center m-3 ">
  <div class="container">
    <h1 class="text-danger shadd"><span><img src="img/productos/pronto152.png" height="45px" > </span>  DOMINGOS PARRILLA</h1>
    <img src="img/prontoW.png" width="" height="50px" alt=""/>
    <p class="small">Av. Francisco de Haro 5285 - Posadas Misiones</p>
    <p> <strong> ABIERTO de Lunes a Domingos de 8.00hs. a 0.00hs. de CORRIDO </strong> </p>
    <p class="small"><strong>PEDIDOS al </strong><span><img src="img/whatsapp.png" width="20px" height="20px"  ></span>  (54)3765-059161 - <span><img src="img/whatsapp.png" width="20px" height="20px"  ></span>  (54)3764-634166 </p>
  </div>
</div>