<div class="jumbotron jumbotron-fluid bg-warning text-center m-3 ">
  <div class="container">
     <p class="text-uppercase">Aceptamos Todas las tarjetas de Creditos, Debitos y QR</p>
     <a class="text-danger" href="https://wa.me/543764634166?text=Me%20gustaría%20que%20me%20envien%20" target="_blank"  >  <img src="img/whatsapp.png" width="50px" height="50px" alt="" title="comunicate con Sandra" ></a>
    <img src="img/prontoW.png" width="" height="45px" alt=""/>
    <a href="https://wa.me/543765059161?text=Me%20gustaría%20que%20me%20envien%20" target="_blank" ><img src="img/whatsapp.png"  width="50px" height="50px" alt="" title="comunicate con el Local" ></a>

    <p class="small">Av. Francisco de Haro 5285 - Posadas Misiones</p>
    
    <p class="small"> <strong>PEDIDOS al </strong><span> <img src="img/whatsapp.png" width="20px" height="20px"  ></span>  (54)3765-059161 - <span><img src="img/whatsapp.png" width="20px" height="20px"  ></span>  (54)3764-634166 </p>

    <div class="row">
       <div class="col-ms m-auto">
        <p class="text-uppercase m-3">visitanos en....</p>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3542.3375404004864!2d-55.9075996854343!3d-27.396397120147387!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x79c449da53b2fa05!2sPronto%20Ya!5e0!3m2!1ses!2snl!4v1583929575269!5m2!1ses!2snl"  width="320"  height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
          </div>

          <div class="col-ms m-auto ">
      <p class="text-uppercase m-3">escribinos....</p>
        <div class="container bg-light p-3">
          <form>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="name">Nombre</label>
                      <input type="text" class="form-control" id="name"  placeholder="Tu nombre..." required>
                    </div>
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">Email</label>
                      <input type="email" class="form-control" id="inputEmail4"placeholder="Tu E-mail..." required>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-12">
                      <label for="coment">Comentario</label>
                      <textarea class="form-control" id="coment" rows="7" placeholder="Tu comentario..." required></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                  <div class="form-check">
                      <input class="form-check-input is-invalid" type="checkbox" value="" id="invalidCheck3" required>
                      <label class="form-check-label" for="invalidCheck3">
                          Aceptar los términos y condiciones
                      </label>
                      <div class="invalid-feedback">
                         Debe aceptar antes de enviar.
                      </div>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary">Enviar</button>
          </form>
          </div>
          </div>
    </div>
    </br>
    <p> <strong> ABIERTO de Lunes a Domingos de 8.00hs. a 0.00hs. de CORRIDO </strong> </p>
    </br>
    <img src="img/cobrarQR.jpg"  height="400px" alt="noTa">
    </br>  </br>
    <p class="small">www.prontoya.com - © Copyright 2020  </br>
     by <b>kvalhost System ®</b>  <a href="https://wa.me/543765119303?text=Me%20gustaría%20comunicarme%20con%20Ustedes%20" target="_blank" ><img src="img/whatsapp.png"  width="20px" height="20px" alt="" title="comunicate con kvalhost System" ></a> </p>
  </div>
</div> 